import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';

import { StaffUsersService } from '../../staff-users/staff-users.service';
import { AuthenticatedRequest } from '../interfaces/authenticated-request.interface';
import { JwtPayload } from '../interfaces/jwt-payload.interface';

@Injectable()
export class StaffJwtGuard implements CanActivate {
  constructor(
    private readonly jwtService: JwtService,
    private readonly staffUsersService: StaffUsersService,
  ) {}

  async canActivate(
    context: ExecutionContext,
  ): Promise<boolean> {
    const request =
      context.switchToHttp().getRequest<AuthenticatedRequest>();

    const token = this.extractBearerToken(request);

    if (!token) {
      throw new UnauthorizedException(
        'Se requiere iniciar sesión',
      );
    }

    try {
      const payload =
        await this.jwtService.verifyAsync<JwtPayload>(
          token,
        );

      if (
        payload.accountType !== 'STAFF' ||
        !payload.sub ||
        !payload.businessId
      ) {
        throw new UnauthorizedException(
          'El token no pertenece a un trabajador',
        );
      }

      const staffUser =
        await this.staffUsersService.findById(
          payload.sub,
        );

      if (
        !staffUser.active ||
        staffUser.businessId.toString() !==
          payload.businessId
      ) {
        throw new UnauthorizedException(
          'La cuenta no tiene acceso al negocio',
        );
      }

      request.authUser = {
        id: staffUser._id.toString(),
        accountType: 'STAFF',
        businessId:
          staffUser.businessId.toString(),
        role: staffUser.role,
      };

      return true;
    } catch {
      throw new UnauthorizedException(
        'La sesión no es válida o ha expirado',
      );
    }
  }

  private extractBearerToken(
    request: AuthenticatedRequest,
  ): string | undefined {
    const authorization =
      request.headers.authorization;

    if (!authorization) {
      return undefined;
    }

    const [type, token] =
      authorization.split(' ');

    if (type !== 'Bearer' || !token) {
      return undefined;
    }

    return token;
  }
}